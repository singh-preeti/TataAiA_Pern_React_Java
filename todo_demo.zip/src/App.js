import React, { Fragment } from "react";
import "./App.css";

import InputTodo from "./Components/InputTodo";
//import ListTodos from "./components/ListTodos";

function App() {
  return (
    <Fragment>
      <div>
        <InputTodo />
       
      </div>
    </Fragment>
  );
}

export default App;
