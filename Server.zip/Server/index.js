const express = require("express");
const app = express();
const cors = require("cors");
const pool = require("./db")

//middleware 
app.use(cors());
//to get data from the client
app.use(express.json());
// to add data
app.post("/todos", async (req, res) => {
  //await
  try {
    const { name,salary,age } = req.body;
    
    const newTodo = await pool.query(
      "INSERT INTO employee (name,salary,age) VALUES($1,$2,$3)",
   // insert into employee values('abc',2000,20);
      [name,salary,age]
    );

    res.json(newTodo);
  } catch (err) {
    console.error(err.message);
  }
});
//get all todos
// app.get("/a", async (req, res) => {
//   try {
//     const allTodos = await pool.query("SELECT * FROM todo");
//     res.json(allTodos.rows);
//   } catch (err) {
//     console.error(err.message);
//   }
// });
// //get a todo
// app.get("/get/:id", async (req, res) => {
//   try {
//     const { id } = req.params;
//     const todo = await pool.query("SELECT * FROM todo WHERE id = $1", [
//       id
//     ]);

//     res.json(todo.rows[0]);
//   } catch (err) {
//     console.error(err.message);
//   }
// });

// //update/Put todo
app.put("/update/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { name,salary1,age1} = req.body;
    //const {salary} = req.body;
    const updateTodo = await pool.query(
      "UPDATE employee SET name = $1 WHERE id = $2",
      [name, id]
    );

    res.json("Todo was updated!");
  } catch (err) {
    console.error(err.message);
  }
});

app.listen(5000 , () => {
    console.log("server started on 5000!");
});